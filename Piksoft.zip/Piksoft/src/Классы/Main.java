package Классы;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        Student student1 = new Student(" Залкар "," мужик "," Залкар.com");
        Student student2 = new Student(" Зфар "," мужик "," Зафар.com");
        Student student3 = new Student(" Рамазан "," мужик "," Рамазан.com");
        Student student4 = new Student(" Расул "," мужик "," Расул.com");
        Student student5 = new Student(" Тунук "," девочка "," Тунук.com");
        Student student6 = new Student(" Нуртилке "," мужик "," Нуртилке.com");
        Student student7 = new Student(" Нурел "," мужик "," Нурел.com");
        Student student8 = new Student(" Нураида "," девочка "," Нураида.com");
        Student student9 = new Student(" Нурмухамед "," мужик "," Нурмухамед.com");

        Student[] students = {student1,student2,student3,student6,student4,student5,student7,student8,student9};
        Student[] students1 = {student1,student2,student3};
        Student[] students2 = {student4,student5,student6};
        Student[] students3 = {student7,student8,student9};

        Group group1 = new Group(" Java 12\n ",students1,5);
        Group group2 = new Group(" Java 11\n ",students2,5);
        Group group3 = new Group(" Java 10\n ",students3,5);

        Group [] group4 = {group1};
        Group [] group5 = {group2};
        Group [] group6 = {group3};

        Mentor mentor1 = new Mentor(" Назима "," девочка "," Назима.com\n",group4);
        Mentor mentor2 = new Mentor(" Назима "," девочка "," Назима.com\n",group5);
        Mentor mentor3 = new Mentor(" Назима "," девочка "," Назима.com\n",group6);

        Mentor mentor4 = new Mentor(" Назима "," девочка "," Назима.com");
        Mentor mentor5 = new Mentor(" Максим "," мужик "," Максим.com");
        Mentor mentor6 = new Mentor(" Нураида "," девочка "," Нураида.com");
        Mentor [] mentor = {mentor4,mentor5,mentor6};

        System.out.print("""
                1 -> Вывести всех студентав: 
                2 -> Вывести всех ментарав: 
                3 -> Найти студента по имени: 
                4 -> Найти ментора по email:
                5 -> Вывести студентав в алфавитном парядке:
                6 -> Вывести с начала девочек а патом мальчиков:
                """);
            int aa = scanner.nextInt();
            switch (aa) {
                case 1:
                    System.out.println(Arrays.toString(metodStudents(students)));
                    break;
                case 2:
                    System.out.println(Arrays.toString(metodMentors(mentor)));
                    break;
                case 3:
                    System.out.println(" Ведите имя :");
                    String ss = scanner.next();
                    switch (ss) {
                        case "Залкар":
                            System.out.println(student1);
                            break;
                        case "Зфар":
                            System.out.println(student2);
                            break;
                        case "Рамазан":
                            System.out.println(student3);
                            break;
                        case "Расул":
                            System.out.println(student4);
                            break;
                        case "Тунук":
                            System.out.println(student5);
                            break;
                        case "Нуртилке":
                            System.out.println(student6);
                            break;
                        case "Нурел":
                            System.out.println(student7);
                            break;
                        case "Нураида":
                            System.out.println(student8);
                            break;
                        case "Нурмухамед":
                            System.out.println(student9);
                            break;
                    }
                    break;
                case 4:
                    System.out.println("Ведите email");
                    String dd = scanner.next();
                    switch (dd) {
                        case "Назима.com":
                            System.out.println(mentor4);
                            break;
                        case "Максим.com":
                            System.out.println(mentor5);
                            break;
                        case "Нураида.com":
                            System.out.println(mentor6);
                    }
                case 5:
                    Arrays.sort(students, Comparator.comparing(Student::getName));
                    for (Student student : students) {
                        System.out.println(student);
                    }
                case 6:
                    Arrays.sort(students, Comparator.comparing(Student::getGender)
                            .thenComparing(Student::getName));
                    for (Student student : students) {
                        System.out.println(student);
                    }
            }

        }

    public static Student[] metodStudents(Student[] students){
        return students;
    }
    public  static Mentor [] metodMentors(Mentor [] mentor ){
        return mentor;
    }

}
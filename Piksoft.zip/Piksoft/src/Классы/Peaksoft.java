package Классы;

import Классы.Mentor;

import java.util.Arrays;

public class Peaksoft {
    private String name;
    private String address;
    private Mentor[] mentor;
    private Student[] student;

    public Peaksoft(String name, String address, Mentor[] mentor, Student[] student) {
        this.name = name;
        this.address = address;
        this.mentor = mentor;
        this.student = student;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Mentor[] getMentor() {
        return mentor;
    }

    public void setMentor(Mentor[] mentor) {
        this.mentor = mentor;
    }

    public Student[] getStudent() {
        return student;
    }

    public void setStudent(Student[] student) {
        this.student = student;
    }

    @Override
    public String toString() {
        return "Классы.Peaksoft{" +
                "name = " + name  +
                ", address = " + address  +
                ", mentor = " + Arrays.toString(mentor) +
                ", student = " + Arrays.toString(student) +
                '}';
    }
}

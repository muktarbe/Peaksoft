package Классы;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Student {
    private String name;
    private String gender;
    private String email;

    public Student(String name, String gender, String email) {
        this.name = name;
        this.gender = gender;
        this.email = email;
    }



    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return " Студенты " +
                "имя =" + name +
                ", пол =" + gender +
                ", email =" + email +
                "\n";
    }
}

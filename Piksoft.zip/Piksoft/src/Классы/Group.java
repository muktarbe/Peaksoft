package Классы;

import java.util.Arrays;

public class Group {
    private String name;
    private Student[] student;
    private int count;

    public Group(String name, Student[] student, int count) {
        this.name = name;
        this.student = student;
        this.count = count;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Student[] getStudent() {
        return student;
    }

    public void setStudent(Student[] student) {
        this.student = student;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString() {
        return "Група " +
                "название групы = " + name  +
                ", студенты = " + Arrays.toString(student) +
                ", count = " + count +
                "\n";
    }
}
